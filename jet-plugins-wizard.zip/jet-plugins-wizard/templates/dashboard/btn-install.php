<?php
/**
 * Install button template
 */
?>
<button data-action="install" class="wizard-plugin__install wizard-plugin__link"><span class="text"><?php
		esc_html_e( 'Install', 'jet-plugins-wizard' );
	?></span><span class="jet-plugins-wizard-loader"><span class="jet-plugins-wizard-loader__spinner"></span></span>
</buttom>