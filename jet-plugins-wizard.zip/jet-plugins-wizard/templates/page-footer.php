<?php
/**
 * Page footer template
 */
?>
	<?php jet_plugins_wizard()->get_template( 'select-type-popup.php' ); ?>
	</div>
</div>

<?php do_action( 'jet_plugins_wizard_main_after' ); ?>
