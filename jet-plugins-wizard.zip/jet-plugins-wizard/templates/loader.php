<?php
/**
 * Plugin item loader
 */
?>
<div class="jet-plugins-wizard-loader"><div class="jet-plugins-wizard-loader__spinner"></div></div>