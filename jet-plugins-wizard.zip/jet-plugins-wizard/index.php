<?php
/**
 * Silence is golden
 */
